package com.example.examen1.data

data class Producto (val nombre: String, val precio: Int)







